# Riscos e Mitigação

| Risco | Mitigação |
|---|---|
Dados incompletos | Validação + logs |
Integração lenta | CSV primeiro, API depois |
Alertas falsos | Threshold + revisão |
LGPD | Anonimização |

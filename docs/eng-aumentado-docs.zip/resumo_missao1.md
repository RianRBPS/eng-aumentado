# Resumo Missão 1

Sistema estadual para monitorar hemogramas, detectar surtos e apoiar decisões, com foco inicial em:
- Dengue
- Anemia infantil e geriátrica
- Vigilância HIV e tabagismo

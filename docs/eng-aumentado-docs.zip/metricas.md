# Métricas e Hipóteses

| Hipótese | Métrica | Meta |
|---|---|---|
Alertas reduzem tempo de resposta | Dias entre detecção e ação | -3 dias |
Painel escolar reduz anemia | Prevalência após 6 meses | -20% |
Mapa acelera intervenção | Tempo até ação municipal | -30% |

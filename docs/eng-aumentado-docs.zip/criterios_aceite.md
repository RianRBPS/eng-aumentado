# Critérios de Aceite — MVP

## HU: Ver plaquetas no estado
- Dashboard exibe valores médios por município
- Heatmap com intensidade por risco
- Alertas quando média < 100k ou queda ≥ 15% em 72h

## HU: Alertas automáticos
- Detecta variação brusca
- Marca hotspot no mapa
- Notifica equipe

## HU: Filtrar população escolar e idosa
- Filtro 0–12 mostra anemia e eosinofilia
- Filtro 60+ mostra anemia e hematócrito

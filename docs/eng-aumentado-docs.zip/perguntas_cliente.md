# Perguntas ao Cliente

## Estratégia
- Quais indicadores priorizar no MVP?
- Escolas ou idosos como foco inicial?

## Dados
- Frequência de atualização?
- Formato dos dados (FHIR/CSV/API)?

## LGPD
- Anonimização ou pseudonimização?
- Tempo de retenção?

## Operacional
- Quem valida alertas?
- Relatórios automáticos mensais?

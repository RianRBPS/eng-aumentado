# Personas do Sistema

| Persona | Objetivo | Dor |
|---|---|---|
Gestor Estadual | Planejar políticas | Dados fragmentados |
Epidemiologista | Detectar surtos cedo | Falha de alerta precoce |
Pesquisador | Analisar populações | Acesso burocrático |
Agente Municipal | Resposta rápida | Falta de sinalização |
Laboratórios | Enviar dados | Padronização |

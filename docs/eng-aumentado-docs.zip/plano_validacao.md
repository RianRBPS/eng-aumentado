# Plano de Validação

1. Importar lote histórico
2. Gerar dashboards
3. Simular queda de plaquetas
4. Verificar alerta + mapa
5. Revisão com epidemiologista
